DILKI MADUSHANI — DIGITAL MARKETING PORTFOLIO WEBSITE

FILES
- index.html: complete responsive portfolio website. Open it in a browser to preview.

BEFORE SHARING WITH EMPLOYERS
1. Replace the three placeholder project panels with real samples or link buttons.
2. Add actual image files for your Canva designs and thumbnails if you want the site to show them.
3. Replace “Add video link before sharing” with a real, publicly viewable link to your Yarl Advertising Fiesta video.
4. Add only authentic work and describe your role accurately.
5. Check all links and contact details.

HOW TO PUBLISH FOR FREE
Option A — Google Sites:
- Create a new site at https://sites.google.com/
- Copy the text and sections from index.html into Google Sites sections.
- Add your images/videos and publish. Google Sites does not directly import an HTML file as a complete website.

Option B — GitHub Pages (publishes this HTML file):
- Sign in or create an account at https://github.com/
- Create a new public repository, e.g. dilki-digital-portfolio.
- Upload index.html to the repository root.
- Open Settings → Pages; choose Deploy from a branch, select main and /(root), then Save.
- Wait for the published URL to appear in the Pages section.
- Test the website on mobile and desktop before emailing the link.

You can also preview index.html locally by double-clicking it and opening it in a browser.
